import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

import org.junit.After as After
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.testdata.InternalData as InternalData
import org.openqa.selenium.WebElement as WebELement
import com.kms.katalon.core.testobject.ConditionType as Conditiontype
import com.kms.katalon.core.testobject.SelectorMethod as Selectormethod

WebUI.openBrowser('')

WebUI.navigateToUrl('https://brick-qa-assignment.herokuapp.com/')

WebUI.setText(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_First Name_firstName'), 'Andi')

WebUI.setText(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_Last Name_lastName'), 'Eko')

WebUI.setText(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_Your Email_email'), 'test@mailinator.com')

//WebUI.click(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_Your Address_address'))

WebUI.setText(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_Vietnam (Vit Nam)_phoneNumber'), 
    '81293600000')

WebUI.setText(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_Your Address_address'), 'jalan-jalan')

WebUI.setEncryptedText(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_Password_password'), 
    'RPBXLhk47+o=')

WebUI.setEncryptedText(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_Confirm Password_confirm_password'), 
    'RPBXLhk47+o=')

WebUI.click(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/input_Confirm Password_register'))

WebUI.click(findTestObject('Object Repository/Register Form/Page_Brick Sign Up Form/button_OK'))


